package com.test.savaz;

import android.R.bool;

public class Sessionhandler
{
	Teasession session;
	
	public Sessionhandler(Teasession _session)
	{
		super();
		this.session = _session;
	}

	public boolean setNextBrew()
	{
		
		return false;
		
	}
}
