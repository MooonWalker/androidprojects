package com.test.savaz;


public interface MycountFinished
{
	public void timerFinished();
	
}
